import { getStore } from "@netlify/blobs";
import { createHmac, timingSafeEqual } from "node:crypto";

const STORE_NAME = "message-tree";
const KEY = "messages-v1";
const MAX_MESSAGES = 1200;
const ADMIN_COOKIE = "message_tree_admin";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
};

const json = (body, status = 200, extraHeaders = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...headers, ...extraHeaders },
  });

function clean(value, max) {
  return String(value ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .trim()
    .slice(0, max);
}

function getAdminPassword() {
  return String(globalThis.Netlify?.env?.get?.("ADMIN_PASSWORD") ?? process.env.ADMIN_PASSWORD ?? "").trim();
}

function signTimestamp(timestamp, password) {
  return createHmac("sha256", password)
    .update(`message-tree-admin:${timestamp}`)
    .digest("hex");
}

function validAdminCookie(req) {
  const password = getAdminPassword();
  if (!password) return false;

  const cookieHeader = req.headers.get("cookie") || "";
  const match = cookieHeader.match(new RegExp(`(?:^|;\\s*)${ADMIN_COOKIE}=([^;]+)`));
  if (!match) return false;

  const raw = decodeURIComponent(match[1]);
  const [timestampRaw, signature] = raw.split(".");
  const timestamp = Number(timestampRaw);

  if (!Number.isSafeInteger(timestamp) || !signature) return false;
  if (Date.now() - timestamp > SESSION_TTL_MS || timestamp > Date.now() + 60_000) return false;

  const expected = signTimestamp(timestamp, password);
  try {
    return timingSafeEqual(Buffer.from(signature, "utf8"), Buffer.from(expected, "utf8"));
  } catch {
    return false;
  }
}

function adminCookie(timestamp, password) {
  const value = encodeURIComponent(`${timestamp}.${signTimestamp(timestamp, password)}`);
  const secure = globalThis.Netlify?.env?.get?.("CONTEXT") !== "dev" && process.env.NODE_ENV !== "development";
  return `${ADMIN_COOKIE}=${value}; Path=/; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}; HttpOnly; SameSite=Strict${secure ? "; Secure" : ""}`;
}

function clearAdminCookie() {
  return `${ADMIN_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict; Secure`;
}

export default async (req) => {
  const store = getStore(STORE_NAME);
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "";
  const isAdmin = validAdminCookie(req);

  if (req.method === "GET") {
    const messages = (await store.get(KEY, { type: "json" })) || [];
    return json({ messages, admin: isAdmin });
  }

  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405, { Allow: "GET, POST" });
  }

  try {
    const body = await req.json();

    // Admin login
    if (action === "login") {
      const adminPassword = getAdminPassword();
      if (!adminPassword) {
        return json({ error: "ADMIN_PASSWORD chưa được cấu hình trên Netlify." }, 503);
      }

      const password = String(body.password ?? "");
      const passwordOk = password.length > 0 && password === adminPassword;
      if (!passwordOk) return json({ error: "Mật khẩu quản trị không đúng." }, 401);

      const timestamp = Date.now();
      return json(
        { ok: true, admin: true },
        200,
        { "Set-Cookie": adminCookie(timestamp, adminPassword) },
      );
    }

    // Admin logout
    if (action === "logout") {
      return json({ ok: true, admin: false }, 200, { "Set-Cookie": clearAdminCookie() });
    }

    // Admin-only: delete one message
    if (action === "delete") {
      if (!isAdmin) return json({ error: "Bạn không có quyền quản trị." }, 403);

      const id = clean(body.id, 120);
      if (!id) return json({ error: "Thiếu mã lời nhắn." }, 400);

      const existing = (await store.get(KEY, { type: "json" })) || [];
      const next = existing.filter((item) => String(item.id) !== id);

      if (next.length === existing.length) {
        return json({ error: "Không tìm thấy lời nhắn." }, 404);
      }

      await store.setJSON(KEY, next);
      return json({ ok: true, deletedId: id });
    }

    // Admin-only: delete every message
    if (action === "reset") {
      if (!isAdmin) return json({ error: "Bạn không có quyền quản trị." }, 403);
      await store.delete(KEY);
      return json({ ok: true, messages: [] });
    }

    // Public: create a new message
    if (clean(body.website, 100)) return json({ error: "Spam detected" }, 400);

    const message = clean(body.message, 500);
    const author = clean(body.author, 60) || "Ẩn danh";

    if (!message) return json({ error: "Message is required" }, 400);

    const existing = (await store.get(KEY, { type: "json" })) || [];
    const item = {
      id: crypto.randomUUID(),
      author,
      message,
      createdAt: new Date().toISOString(),
    };

    const next = [...existing, item]
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .slice(-MAX_MESSAGES);

    await store.setJSON(KEY, next);
    return json({ message: item }, 201);
  } catch {
    return json({ error: "Invalid request" }, 400);
  }
};
