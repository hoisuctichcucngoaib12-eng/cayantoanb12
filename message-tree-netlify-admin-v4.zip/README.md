# Cây Lời Nhắn — phiên bản quản trị

Website một trang để gửi và đọc lời nhắn dưới dạng những chiếc lá trên một cây cổ thụ.

## Chức năng
- Mỗi lời nhắn mới tạo ra một chiếc lá có màu và hình dạng tự nhiên khác nhau.
- Khách chỉ có thể gửi và đọc lời nhắn.
- Có khu vực **Quản trị** riêng.
- Quản trị viên có thể:
  - Xóa từng lời nhắn / từng chiếc lá.
  - Reset toàn bộ cây.
  - Đăng xuất khỏi khu vực quản trị.
- Quyền xóa/reset được kiểm tra **ở server Netlify Function**, không chỉ ẩn nút trên giao diện.

## Cấu hình mật khẩu quản trị trên Netlify

Không đặt mật khẩu trực tiếp vào JavaScript frontend.

Sau khi deploy project lên Netlify:

1. Vào **Project configuration → Environment variables**.
2. Chọn **Add a variable**.
3. Name: `ADMIN_PASSWORD`
4. Value: mật khẩu quản trị bạn tự đặt.
5. Lưu lại.
6. Redeploy site.

Nếu chưa cấu hình `ADMIN_PASSWORD`, khu vực quản trị sẽ không cho đăng nhập.

## Deploy

Giữ nguyên toàn bộ cấu trúc project, đặc biệt:

```text
netlify/
└── functions/
    └── messages.mjs
```

`netlify.toml` đã chỉ định thư mục Functions là `netlify/functions`.

## Lưu ý bảo mật

- Mật khẩu không được lưu trong HTML/JS.
- Phiên quản trị dùng cookie HttpOnly + SameSite=Strict và tự hết hạn sau 12 giờ.
- Các API `delete` và `reset` đều kiểm tra quyền quản trị ở server.
